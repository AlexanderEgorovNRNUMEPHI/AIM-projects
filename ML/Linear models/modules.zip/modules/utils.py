import numpy as np


def get_numeric_grad(f, x, eps=1e-6):
    """
    Function to calculate numeric gradient of f function in x.

    Parameters
    ----------
    f : callable
    x : numpy.ndarray
            1d array, function argument
    eps : float
            Tolerance

    Returns
    -------
    : numpy.ndarray
            Numeric gradient.
    """
    matrix_eps = np.full((x.size, x.size), x) + np.diag(np.ones(x.size)) * eps
    matrix_x = np.full((x.size, x.size), x)
    return (
        np.apply_along_axis(f, axis=1, arr=matrix_eps)
        - np.apply_along_axis(f, axis=1, arr=matrix_x)
    ) / eps


def compute_balanced_accuracy(true_y, pred_y):
    """
    Get balanced accuracy value

    Parameters
    ----------
    true_y : numpy.ndarray
            True target.
    pred_y : numpy.ndarray
            Predictions.
    Returns
    -------
    : float
    """
    possible_y = set(true_y)
    value = 0
    for current_y in possible_y:
        mask = true_y == current_y
        value += (pred_y[mask] == current_y).sum() / mask.sum()
    return value / len(possible_y)
