import numpy as np
import scipy
from scipy.special import expit


class BaseLoss:
    """
    Base class for loss function.
    """

    def func(self, X, y, w):
        """
        Get loss function value at w.
        """
        raise NotImplementedError("Func oracle is not implemented.")

    def grad(self, X, y, w):
        """
        Get loss function gradient value at w.
        """
        raise NotImplementedError("Grad oracle is not implemented.")


class BinaryLogisticLoss(BaseLoss):
    """
    Loss function for binary logistic regression.
    It should support l2 regularization.
    """

    def __init__(self, l2_coef):
        """
        Parameters
        ----------
        l2_coef - l2 regularization coefficient
        """
        self.l2_coef = l2_coef

    def func(self, X, y, w):
        """
        Get loss function value for data X, target y and coefficient w; w = [bias, weights].

        Parameters
        ----------
        X : 2d numpy.ndarray
        y : 1d numpy.ndarray
        w : 1d numpy.ndarray

        Returns
        -------
        : float
        """
        A = np.dot(X, w[1:]) + w[0]
        return (
            sum(np.logaddexp(0.0, -y * A)) / A.size
            + self.l2_coef * (np.linalg.norm(w[1:])) ** 2
        )

    def grad(self, X, y, w):
        """
        Get loss function gradient for data X, target y and coefficient w; w = [bias, weights].

        Parameters
        ----------
        X : 2d numpy.ndarray
        y : 1d numpy.ndarray
        w : 1d numpy.ndarray

        Returns
        -------
        : 1d numpy.ndarray
        """
        A = np.dot(X, w[1:]) + w[0]
        grad_weights = (
            -X.T.dot(np.multiply(y, expit(np.multiply(-y, A)))) / A.size
            + 2 * self.l2_coef * w[1:]
        )
        grad_bias = sum(-y * expit(np.multiply(-y, A))) / A.size
        return np.r_[grad_bias, grad_weights]
