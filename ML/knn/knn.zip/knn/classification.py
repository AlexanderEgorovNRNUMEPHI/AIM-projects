import numpy as np
from sklearn.neighbors import NearestNeighbors
from knn.nearest_neighbors import NearestNeighborsFinder


class KNNClassifier:
    EPS = 1e-5

    def __init__(
        self, n_neighbors, algorithm="my_own", metric="euclidean", weights="uniform"
    ):
        if algorithm == "my_own":
            finder = NearestNeighborsFinder(n_neighbors=n_neighbors, metric=metric)
        elif algorithm in (
            "brute",
            "ball_tree",
            "kd_tree",
        ):
            finder = NearestNeighbors(
                n_neighbors=n_neighbors, algorithm=algorithm, metric=metric
            )
        else:
            raise ValueError("Algorithm is not supported", metric)

        if weights not in ("uniform", "distance"):
            raise ValueError("Weighted algorithm is not supported", weights)

        self._finder = finder
        self._weights = weights

    def fit(self, X, y=None):
        self._finder.fit(X)
        self._labels = np.asarray(y)
        return self

    def _predict_precomputed(self, indices, distances):
        # ответы обучающей выборки
        labels = np.take_along_axis(
            np.stack((self._labels,) * indices.shape[0], axis=0), indices, axis=1
        )
        if self._weights != "distance":
            counts = np.apply_along_axis(
                lambda x: np.bincount(x, minlength=len(np.unique(self._labels))),
                axis=1,
                arr=labels,
            )
        else:
            weights = 1 / (distances + self.EPS)
            max_label = np.amax(labels)
            row = labels.shape[0]
            counts = np.empty([row, max_label + 1])
            # применяем построчный bincount в цикле, контролируя minlength
            for i in range(row):
                counts[i, :] = np.bincount(
                    labels[i, :], weights[i, :], minlength=max_label + 1
                )[np.newaxis]
        return np.argmax(counts, axis=1)

    def kneighbors(self, X, return_distance=False):
        return self._finder.kneighbors(X, return_distance=return_distance)

    def predict(self, X):
        distances, indices = self.kneighbors(X, return_distance=True)
        return self._predict_precomputed(indices, distances)


class BatchedKNNClassifier(KNNClassifier):
    """
    Нам нужен этот класс, потому что мы хотим поддержку обработки батчами
    в том числе для классов поиска соседей из sklearn
    """

    def __init__(
        self,
        n_neighbors,
        algorithm="my_own",
        metric="euclidean",
        weights="uniform",
        batch_size=None,
    ):
        KNNClassifier.__init__(
            self,
            n_neighbors=n_neighbors,
            algorithm=algorithm,
            weights=weights,
            metric=metric,
        )
        self._batch_size = batch_size

    def kneighbors(self, X, return_distance=False):
        if self._batch_size is None or self._batch_size >= X.shape[0]:
            return super().kneighbors(X, return_distance=return_distance)
        batch_indices = list(range(0, X.shape[0], self._batch_size)) + [X.shape[0]]
        for left, right in zip(batch_indices[:-1], batch_indices[1:]):
            batch = X[left:right]
            if return_distance:
                dist, ind = super().kneighbors(batch, return_distance=return_distance)
                try:
                    batch_dist = np.vstack((batch_dist, dist))
                    batch_ind = np.vstack((batch_ind, ind))
                except UnboundLocalError:
                    batch_dist = dist
                    batch_ind = ind
            else:
                try:
                    ind = self._finder.kneighbors(
                        batch, return_distance=return_distance
                    )
                    batch_ind = np.vstack((batch_ind, ind))
                except UnboundLocalError:
                    batch_ind = ind
        if return_distance:
            return batch_dist, batch_ind
        return batch_ind
