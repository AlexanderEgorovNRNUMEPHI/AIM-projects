import numpy as np


def euclidean_distance(x, y):
    x_2 = (x**2).sum(axis=1)
    y_2 = (y**2).sum(axis=1)
    return np.sqrt(x.dot(y.T) * (-2) + x_2[np.newaxis, :].T + y_2)


def cosine_distance(x, y):

    return 1 - np.dot(x, y.T) / (
        np.linalg.norm(x, axis=1, keepdims=True)
        * np.linalg.norm(y, axis=1, keepdims=True).T
    )
