from collections import defaultdict

import numpy as np

from sklearn.model_selection import KFold, BaseCrossValidator
from sklearn.metrics import accuracy_score

from knn.classification import BatchedKNNClassifier


def knn_cross_val_score(X, y, k_list, scoring, cv=None, **kwargs):
    y = np.asarray(y)

    if scoring == "accuracy":
        scorer = accuracy_score
    else:
        raise ValueError("Unknown scoring metric", scoring)

    if cv is None:
        cv = KFold(n_splits=5)
    elif not isinstance(cv, BaseCrossValidator):
        raise TypeError("cv should be BaseCrossValidator instance", type(cv))
    result = defaultdict(list)
    for train_index, test_index in cv.split(X):
        classifier = BatchedKNNClassifier(n_neighbors=max(k_list), **kwargs)
        classifier.fit(X[train_index], y[train_index])
        distances, indices = classifier.kneighbors(X[test_index], True)
        for k in k_list:
            result[k].append(
                scorer(
                    y[test_index],
                    classifier._predict_precomputed(indices[:, :k], distances[:, :k]),
                )
            )
    return result
