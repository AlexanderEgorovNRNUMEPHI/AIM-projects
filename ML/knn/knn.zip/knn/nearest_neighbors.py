import numpy as np
from knn.distances import euclidean_distance, cosine_distance


class NearestNeighborsFinder:
    def __init__(self, n_neighbors, metric="euclidean"):
        self.n_neighbors = n_neighbors
        if metric == "euclidean":
            self._metric_func = euclidean_distance
        elif metric == "cosine":
            self._metric_func = cosine_distance
        else:
            raise ValueError("Metric is not supported", metric)
        self.metric = metric

    def fit(self, X, y=None):
        self._X = X
        return self

    def kneighbors(self, X, return_distance=False):
        distances = self._metric_func(X, self._X)
        # Сначала ищем self.n_neighbors - 1 -ю порядковую статистику,
        # затем сортируем
        indices = np.argpartition(distances, kth=self.n_neighbors - 1, axis=1)[
            :, : self.n_neighbors
        ]
        indices = np.take_along_axis(
            indices, np.argsort(np.take_along_axis(distances, indices, axis=1)), axis=1
        )
        if not return_distance:
            return indices
        distances = np.take_along_axis(distances, indices, axis=1)
        return distances, indices
